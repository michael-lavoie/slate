/**
 * Rich Text Editor
 * -----------------------------------------------------------------------------
 * Wrap videos in div to force responsive layout.
 *
 * @namespace rte
 */

slate.rte = {

	wrapTable: function() {
		$('.rte table').wrap('<div class="rte__table-wrapper"></div>');
	},

	iframeReset: function() {
		var $iframeVideo = $('.rte iframe[src*="youtube.com/embed"], .rte iframe[src*="player.vimeo"]');
		var $iframeReset = $iframeVideo.add('.rte iframe#admin_bar_iframe');

		$iframeVideo.each(function() {
			// Add wrapper to make video responsive
			$(this).wrap('<div class="rte__video-wrapper"></div>');
		});

		$iframeReset.each(function() {
			// Re-set the src attribute on each iframe after page load
			// for Chrome's "incorrect iFrame content on 'back'" bug.
			// https://code.google.com/p/chromium/issues/detail?id=395791
			// Need to specifically target video and admin bar
			this.src = this.src;
		});
	}
};
